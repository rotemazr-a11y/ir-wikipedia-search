"""
DataFrame-Based PageRank Computation for Wikipedia Link Graph

This module implements iterative PageRank using PySpark DataFrames (the "hybrid" approach).
It extracts the link graph from Wikipedia and computes static PageRank scores that will
be used to boost document scores in the search engine.

PageRank Formula:
    PR(d) = (1-α)/N + α * Σ_{p in inlinks(d)} PR(p) / |outlinks(p)|

where:
- α (damping factor) = 0.85 (standard value)
- N = total number of pages
- inlinks(d) = pages linking to d
- outlinks(p) = outgoing links from page p

Architecture:
- Uses DataFrames (not RDDs) for better query optimization
- Implements iterative matrix multiplication (10-15 iterations)
- Handles dangling nodes (pages with no outlinks)
- Normalizes final scores to [0, 1] range
"""

import logging
from pathlib import Path
from typing import Dict, Tuple
import pickle

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, sum as _sum, count, lit, broadcast, explode, array
from pyspark.sql.types import StructType, StructField, IntegerType, FloatType, ArrayType

from .inverted_index_gcp import get_bucket, _open

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PageRankComputer:
    """
    Computes PageRank scores for Wikipedia articles using PySpark DataFrames.

    This implementation uses DataFrames (not RDDs) because:
    1. PageRank involves many joins (src_page -> dst_page), which DataFrames optimize
    2. Catalyst optimizer automatically chooses broadcast vs. shuffle joins
    3. Cleaner code than manual RDD transformations
    """

    def __init__(self, spark: SparkSession, damping_factor: float = 0.85):
        """
        Initialize PageRank computer.

        Parameters:
        -----------
        spark : SparkSession
            Active Spark session
        damping_factor : float, default=0.85
            Probability of following a link (standard value is 0.85)
        """
        self.spark = spark
        self.damping_factor = damping_factor
        logger.info(f"PageRankComputer initialized (damping={damping_factor})")

    def extract_link_graph(self,
                          wikipedia_dump_path: str,
                          min_links: int = 1) -> DataFrame:
        """
        Extract link graph from Wikipedia dump.

        Expected input format (Parquet or JSON):
        - doc_id: int (Wikipedia article ID)
        - title: str
        - links: list of int (IDs of articles this page links to)

        Parameters:
        -----------
        wikipedia_dump_path : str
            Path to Wikipedia dump (e.g., "gs://wiki-dump/*.parquet")
        min_links : int, default=1
            Filter out pages with fewer than this many outlinks

        Returns:
        --------
        DataFrame with schema: (src_id, dst_id, num_outlinks)
            - src_id: Source page ID
            - dst_id: Destination page ID (one row per link)
            - num_outlinks: Total number of outlinks from src_id (for normalization)
        """
        logger.info("Extracting link graph from Wikipedia dump...")

        # Read Wikipedia dump
        if wikipedia_dump_path.endswith('.parquet') or '*.parquet' in wikipedia_dump_path:
            wiki_df = self.spark.read.parquet(wikipedia_dump_path)
        else:
            wiki_df = self.spark.read.json(wikipedia_dump_path)

        # Extract relevant columns
        # Normalize column names (handle both 'doc_id' and 'id')
        if 'doc_id' in wiki_df.columns:
            wiki_df = wiki_df.withColumnRenamed('doc_id', 'id')

        # Select id and links
        links_df = wiki_df.select(
            col('id').alias('src_id'),
            col('links')  # Assuming this is an array of integers
        ).filter(col('links').isNotNull())

        # Explode links: one row per (src_id, dst_id) pair
        edges_df = links_df.select(
            col('src_id'),
            explode(col('links')).alias('dst_id')
        ).filter(col('dst_id').isNotNull())

        # Count outlinks per source page
        outlink_counts = edges_df.groupBy('src_id') \
                                 .agg(count('dst_id').alias('num_outlinks'))

        # Join back to edges
        edges_with_counts = edges_df.join(
            outlink_counts,
            on='src_id',
            how='left'
        )

        # Filter out nodes with too few outlinks
        if min_links > 1:
            edges_with_counts = edges_with_counts.filter(col('num_outlinks') >= min_links)

        num_edges = edges_with_counts.count()
        num_nodes = edges_with_counts.select('src_id').distinct().count()

        logger.info(f"✓ Link graph extracted: {num_nodes:,} nodes, {num_edges:,} edges")

        return edges_with_counts

    def compute_pagerank(self,
                        edges_df: DataFrame,
                        num_iterations: int = 10,
                        convergence_threshold: float = 0.01) -> Dict[int, float]:
        """
        Compute PageRank using iterative matrix multiplication.

        Algorithm:
        1. Initialize all pages with PR = 1/N
        2. For each iteration:
            a. Compute contributions: each page p sends PR(p)/|outlinks(p)| to each outlink
            b. Sum contributions for each page
            c. Apply damping: PR_new(d) = (1-α)/N + α * Σ contributions
        3. Repeat until convergence or max iterations

        Parameters:
        -----------
        edges_df : DataFrame
            Link graph from extract_link_graph() (src_id, dst_id, num_outlinks)
        num_iterations : int, default=10
            Maximum number of iterations
        convergence_threshold : float, default=0.01
            Stop if max PR change < this threshold

        Returns:
        --------
        dict : page_id -> PageRank score
        """
        logger.info("="*70)
        logger.info(f"Computing PageRank ({num_iterations} iterations, α={self.damping_factor})")
        logger.info("="*70)

        # Get all unique page IDs (both src and dst)
        all_pages = edges_df.select(col('src_id').alias('page_id')) \
                            .union(edges_df.select(col('dst_id').alias('page_id'))) \
                            .distinct()

        N = all_pages.count()
        logger.info(f"Total pages in link graph: {N:,}")

        # Initialize PageRank: PR(p) = 1/N
        pagerank_df = all_pages.withColumn('pagerank', lit(1.0 / N))

        # Cache edges (reused every iteration)
        edges_df = edges_df.cache()

        # Iterative computation
        for iteration in range(num_iterations):
            logger.info(f"\nIteration {iteration + 1}/{num_iterations}")

            # STEP 1: Compute contributions from each page to its outlinks
            # contribution(p -> q) = PR(p) / |outlinks(p)|
            contributions_df = edges_df.join(
                pagerank_df,
                edges_df.src_id == pagerank_df.page_id,
                how='inner'
            ).withColumn(
                'contribution',
                col('pagerank') / col('num_outlinks')
            ).select(
                col('dst_id').alias('page_id'),
                col('contribution')
            )

            # STEP 2: Sum contributions for each destination page
            incoming_pr = contributions_df.groupBy('page_id') \
                                          .agg(_sum('contribution').alias('incoming_sum'))

            # STEP 3: Apply damping formula
            # PR_new(d) = (1-α)/N + α * incoming_sum
            new_pagerank_df = all_pages.join(
                incoming_pr,
                on='page_id',
                how='left'
            ).fillna({'incoming_sum': 0.0}) \
             .withColumn(
                 'pagerank',
                 lit((1 - self.damping_factor) / N) + lit(self.damping_factor) * col('incoming_sum')
             ).select('page_id', 'pagerank')

            # Check convergence (optional, expensive to compute)
            if iteration > 0 and iteration % 3 == 0:
                # Sample 1000 pages to estimate convergence
                sample_old = pagerank_df.sample(False, min(1000.0 / N, 1.0)).collect()
                sample_new = new_pagerank_df.sample(False, min(1000.0 / N, 1.0)).collect()

                if len(sample_old) > 0 and len(sample_new) > 0:
                    max_change = max(abs(new.pagerank - old.pagerank)
                                   for old, new in zip(sample_old, sample_new))
                    logger.info(f"  Max PR change (sample): {max_change:.6f}")

                    if max_change < convergence_threshold:
                        logger.info(f"  ✓ Converged at iteration {iteration + 1}")
                        break

            # Update for next iteration
            pagerank_df = new_pagerank_df

        edges_df.unpersist()

        # Collect final PageRank scores
        logger.info("\nCollecting PageRank scores...")
        pagerank_scores = {row.page_id: row.pagerank for row in pagerank_df.collect()}

        # Normalize scores to [0, 1] range
        max_pr = max(pagerank_scores.values()) if pagerank_scores else 1.0
        pagerank_scores = {page_id: pr / max_pr for page_id, pr in pagerank_scores.items()}

        logger.info(f"✓ PageRank computed for {len(pagerank_scores):,} pages")
        logger.info(f"  Max PageRank (normalized): {max(pagerank_scores.values()):.6f}")
        logger.info(f"  Min PageRank (normalized): {min(pagerank_scores.values()):.6f}")

        return pagerank_scores

    def save_pagerank(self,
                     pagerank_scores: Dict[int, float],
                     output_path: str,
                     bucket_name: str = None):
        """
        Save PageRank scores to pickle file.

        Parameters:
        -----------
        pagerank_scores : dict
            page_id -> PageRank score
        output_path : str
            Output file path (e.g., "gs://my-bucket/pagerank.pkl")
        bucket_name : str, optional
            GCS bucket name
        """
        logger.info(f"Saving PageRank scores to {output_path}...")

        bucket = None if bucket_name is None else get_bucket(bucket_name)
        with _open(output_path, 'wb', bucket) as f:
            pickle.dump(pagerank_scores, f)

        logger.info(f"✓ PageRank saved ({len(pagerank_scores):,} pages)")

    @staticmethod
    def load_pagerank(input_path: str, bucket_name: str = None) -> Dict[int, float]:
        """
        Load PageRank scores from pickle file.

        Parameters:
        -----------
        input_path : str
            Path to PageRank pickle file
        bucket_name : str, optional
            GCS bucket name

        Returns:
        --------
        dict : page_id -> PageRank score
        """
        bucket = None if bucket_name is None else get_bucket(bucket_name)
        with _open(input_path, 'rb', bucket) as f:
            pagerank_scores = pickle.load(f)

        logger.info(f"✓ PageRank loaded ({len(pagerank_scores):,} pages)")
        return pagerank_scores


def main():
    """
    Entry point for spark-submit.

    Usage:
        spark-submit pagerank_computer.py \
            --input gs://wiki-dump/*.parquet \
            --output gs://my-bucket/pagerank.pkl \
            --iterations 15
    """
    import argparse

    parser = argparse.ArgumentParser(description='Compute PageRank for Wikipedia')
    parser.add_argument('--input', required=True, help='Wikipedia dump path')
    parser.add_argument('--output', required=True, help='Output path for PageRank pickle')
    parser.add_argument('--bucket', default=None, help='GCS bucket name')
    parser.add_argument('--iterations', type=int, default=10, help='Number of iterations')
    parser.add_argument('--damping', type=float, default=0.85, help='Damping factor')

    args = parser.parse_args()

    # Initialize Spark
    spark = SparkSession.builder \
        .appName("Wikipedia PageRank Computation") \
        .getOrCreate()

    # Compute PageRank
    computer = PageRankComputer(spark, damping_factor=args.damping)

    # Extract link graph
    edges_df = computer.extract_link_graph(args.input)

    # Compute scores
    pagerank_scores = computer.compute_pagerank(edges_df, num_iterations=args.iterations)

    # Save
    computer.save_pagerank(pagerank_scores, args.output, args.bucket)

    logger.info("\n" + "="*70)
    logger.info("PAGERANK COMPUTATION COMPLETE!")
    logger.info("="*70)

    spark.stop()


if __name__ == "__main__":
    main()
