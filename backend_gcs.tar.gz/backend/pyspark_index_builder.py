"""
PySpark-Based Distributed Index Builder for Wikipedia Search Engine

This module implements a production-grade, distributed indexing pipeline using PySpark.
It solves the critical scalability issues identified in the diagnostic audit:
- Memory Efficiency: Processes documents in streaming batches (no OOM)
- MapReduce Architecture: Uses RDD transformations for distributed processing
- SPIMI Algorithm: Single-Pass In-Memory Indexing with disk-based merging

Architecture:
1. RDD-based document processing (streaming, no full dataset in RAM)
2. flatMap() -> reduceByKey() for posting list aggregation
3. Binary posting list output compatible with inverted_index_gcp.py
4. Pre-computed L2 norms for cosine similarity

Usage:
    spark-submit --master yarn --num-executors 10 pyspark_index_builder.py \
        --input gs://wiki-dump/parquet/*.parquet \
        --output gs://my-bucket/indices/
"""

import sys
import logging
from pathlib import Path
from collections import Counter, defaultdict
from typing import List, Tuple, Dict, Iterator
import pickle
import math

from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession

# Import your existing modules
from .pre_processing import tokenize_and_process
from .inverted_index_gcp import InvertedIndex, MultiFileWriter, TUPLE_SIZE, TF_MASK

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class PySparkIndexBuilder:
    """
    Distributed index builder using PySpark RDDs.

    Solves the OOM problem by:
    - Never loading all documents into a single dictionary
    - Processing documents in parallel across Dataproc nodes
    - Using reduceByKey() instead of groupByKey() to avoid memory spikes
    """

    def __init__(self, spark: SparkSession):
        """
        Initialize the PySpark index builder.

        Parameters:
        -----------
        spark : SparkSession
            Active Spark session (created externally or via get_or_create)
        """
        self.spark = spark
        self.sc = spark.sparkContext
        logger.info(f"PySparkIndexBuilder initialized with {self.sc.defaultParallelism} partitions")

    @staticmethod
    def parse_wikipedia_document(row) -> Tuple[int, Dict[str, str]]:
        """
        Parse a single Wikipedia document from Parquet/JSON format.

        Expected schema:
        - doc_id: int
        - title: str
        - body: str (main article text)
        - anchors: list of str (incoming link texts)

        Parameters:
        -----------
        row : pyspark.sql.Row or dict
            Document data

        Returns:
        --------
        tuple : (doc_id, {'title': str, 'body': str, 'anchors': str})
        """
        try:
            doc_id = int(row['id']) if 'id' in row else int(row['doc_id'])
            title = row.get('title', '')
            body = row.get('text', row.get('body', ''))

            # Handle anchor text (may be list or string)
            anchors = row.get('anchor_text', row.get('anchors', []))
            if isinstance(anchors, list):
                anchors_text = ' '.join(anchors)
            else:
                anchors_text = str(anchors) if anchors else ''

            return (doc_id, {
                'title': title,
                'body': body,
                'anchors': anchors_text
            })
        except Exception as e:
            logger.error(f"Failed to parse document: {e}")
            return (None, None)

    @staticmethod
    def emit_term_doc_pairs_body(doc_tuple: Tuple[int, Dict[str, str]]) -> Iterator[Tuple[str, Tuple[int, int]]]:
        """
        Emit (term, (doc_id, tf)) pairs for BODY index.

        This is the MAP phase of MapReduce.

        Parameters:
        -----------
        doc_tuple : (doc_id, {'title': ..., 'body': ..., 'anchors': ...})

        Yields:
        -------
        (term, (doc_id, tf)) : Term and its frequency in this document
        """
        doc_id, content = doc_tuple
        if doc_id is None or not content:
            return

        body_text = content.get('body', '')
        if not body_text:
            return

        # Tokenize with stemming (STEP 1 improvement)
        tokens = tokenize_and_process(body_text, remove_stops=True, stem=True)

        # Count term frequencies
        term_counts = Counter(tokens)

        # Emit (term, (doc_id, tf)) pairs
        for term, tf in term_counts.items():
            yield (term, (doc_id, tf))

    @staticmethod
    def emit_term_doc_pairs_title(doc_tuple: Tuple[int, Dict[str, str]]) -> Iterator[Tuple[str, Tuple[int, int]]]:
        """Emit (term, (doc_id, tf)) pairs for TITLE index."""
        doc_id, content = doc_tuple
        if doc_id is None or not content:
            return

        title_text = content.get('title', '')
        if not title_text:
            return

        tokens = tokenize_and_process(title_text, remove_stops=True, stem=True)
        term_counts = Counter(tokens)

        for term, tf in term_counts.items():
            yield (term, (doc_id, tf))

    @staticmethod
    def emit_term_doc_pairs_anchor(doc_tuple: Tuple[int, Dict[str, str]]) -> Iterator[Tuple[str, Tuple[int, int]]]:
        """Emit (term, (doc_id, tf)) pairs for ANCHOR index."""
        doc_id, content = doc_tuple
        if doc_id is None or not content:
            return

        anchor_text = content.get('anchors', '')
        if not anchor_text:
            return

        tokens = tokenize_and_process(anchor_text, remove_stops=True, stem=True)
        term_counts = Counter(tokens)

        for term, tf in term_counts.items():
            yield (term, (doc_id, tf))

    @staticmethod
    def merge_postings(posting1: List[Tuple[int, int]],
                      posting2: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
        """
        Merge two posting lists for the same term.

        This is the REDUCE phase combiner (used by reduceByKey).

        Parameters:
        -----------
        posting1 : [(doc_id, tf), ...]
        posting2 : [(doc_id, tf), ...]

        Returns:
        --------
        list : Merged posting list
        """
        # Convert to dict for merging
        merged = {}
        for doc_id, tf in posting1:
            merged[doc_id] = merged.get(doc_id, 0) + tf
        for doc_id, tf in posting2:
            merged[doc_id] = merged.get(doc_id, 0) + tf

        # Convert back to list of tuples
        return [(doc_id, tf) for doc_id, tf in merged.items()]

    def build_body_index(self,
                        input_path: str,
                        output_dir: str,
                        num_partitions: int = 200,
                        bucket_name: str = None) -> InvertedIndex:
        """
        Build the BODY inverted index using distributed MapReduce.

        MapReduce Flow:
        1. READ: Load Wikipedia documents from Parquet/JSON
        2. MAP: Parse docs -> emit (term, (doc_id, tf)) pairs
        3. SHUFFLE: Group by term (handled by reduceByKey)
        4. REDUCE: Merge posting lists for each term
        5. WRITE: Binary posting lists to GCS

        Parameters:
        -----------
        input_path : str
            Path to Wikipedia dump (e.g., "gs://wiki-dump/*.parquet")
        output_dir : str
            Output directory for index files
        num_partitions : int, default=200
            Number of partitions for shuffle (tune based on cluster size)
        bucket_name : str, optional
            GCS bucket name for output

        Returns:
        --------
        InvertedIndex
            Index object with df, term_total, posting_locs populated
        """
        logger.info("="*70)
        logger.info("Building BODY index using PySpark MapReduce")
        logger.info("="*70)

        # STEP 1: Load documents as RDD
        logger.info(f"Loading documents from: {input_path}")

        # Read from Parquet (preferred) or JSON
        if input_path.endswith('.parquet') or '*.parquet' in input_path:
            docs_df = self.spark.read.parquet(input_path)
        else:
            docs_df = self.spark.read.json(input_path)

        # Convert to RDD and parse
        docs_rdd = docs_df.rdd.map(PySparkIndexBuilder.parse_wikipedia_document)
        docs_rdd = docs_rdd.filter(lambda x: x[0] is not None)  # Remove failed parses
        docs_rdd.cache()  # Cache parsed docs for reuse

        num_docs = docs_rdd.count()
        logger.info(f"Loaded {num_docs:,} documents")

        # STEP 2: MAP - Emit (term, (doc_id, tf)) pairs
        logger.info("MAP phase: Emitting term-document pairs...")
        term_postings_rdd = docs_rdd.flatMap(PySparkIndexBuilder.emit_term_doc_pairs_body)

        # STEP 3: REDUCE - Aggregate posting lists by term
        logger.info("REDUCE phase: Aggregating posting lists...")
        # Convert (term, (doc_id, tf)) -> (term, [(doc_id, tf)])
        term_postings_grouped = term_postings_rdd.map(lambda x: (x[0], [x[1]])) \
                                                  .reduceByKey(lambda a, b: a + b, numPartitions=num_partitions)

        # Sort posting lists by doc_id (for efficient retrieval)
        term_postings_sorted = term_postings_grouped.mapValues(lambda postings: sorted(postings, key=lambda x: x[0]))

        # STEP 4: Compute document frequency and term totals
        logger.info("Computing DF and term totals...")

        def compute_stats(term_postings_tuple):
            """Compute (df, term_total) for a term."""
            term, postings = term_postings_tuple
            df = len(postings)  # Number of unique documents
            term_total = sum(tf for doc_id, tf in postings)
            return (term, (df, term_total, postings))

        term_stats_rdd = term_postings_sorted.map(compute_stats)

        # Collect stats (small enough to fit in driver memory)
        term_stats = term_stats_rdd.collect()
        logger.info(f"Index contains {len(term_stats):,} unique terms")

        # STEP 5: Write posting lists to binary files
        logger.info("Writing posting lists to disk...")
        index = InvertedIndex()

        # Populate df and term_total
        for term, (df, term_total, postings) in term_stats:
            index.df[term] = df
            index.term_total[term] = term_total

        # Write posting lists in batches (to avoid memory issues)
        self._write_posting_lists_batched(term_stats, output_dir, 'body_index', bucket_name, index)

        # STEP 6: Write index metadata
        index.write_index(output_dir, 'body_index', bucket_name)

        logger.info("✓ BODY index build complete!")
        logger.info(f"  - {len(index.df):,} unique terms")
        logger.info(f"  - {sum(index.df.values()):,} total postings")

        docs_rdd.unpersist()  # Free cached RDD

        return index

    def _write_posting_lists_batched(self,
                                     term_stats: List[Tuple[str, Tuple[int, int, List]]],
                                     output_dir: str,
                                     index_name: str,
                                     bucket_name: str,
                                     index: InvertedIndex,
                                     batch_size: int = 1000):
        """
        Write posting lists to binary files in batches.

        This avoids memory issues when writing millions of posting lists.
        Uses your existing MultiFileWriter from inverted_index_gcp.py.
        """
        from .inverted_index_gcp import MultiFileWriter, get_bucket, _open
        from contextlib import closing

        # Group terms into batches
        batches = [term_stats[i:i+batch_size] for i in range(0, len(term_stats), batch_size)]

        logger.info(f"Writing {len(term_stats)} posting lists in {len(batches)} batches...")

        # Write all posting lists to binary files
        with closing(MultiFileWriter(output_dir, index_name, bucket_name)) as writer:
            for batch_idx, batch in enumerate(batches):
                for term, (df, term_total, postings) in batch:
                    # Encode posting list as binary
                    b = b''.join([
                        (doc_id << 16 | (tf & TF_MASK)).to_bytes(TUPLE_SIZE, 'big')
                        for doc_id, tf in postings
                    ])

                    # Write to file and save locations
                    locs = writer.write(b)
                    index.posting_locs[term].extend(locs)

                if (batch_idx + 1) % 10 == 0:
                    logger.info(f"  Written {(batch_idx + 1) * batch_size:,} terms...")

        # Save posting locations
        posting_locs_path = Path(output_dir) / f'{index_name}_posting_locs.pickle'
        bucket = None if bucket_name is None else get_bucket(bucket_name)
        with _open(str(posting_locs_path), 'wb', bucket) as f:
            pickle.dump(index.posting_locs, f)

        logger.info(f"✓ Posting locations saved to {posting_locs_path}")

    def build_all_indices(self,
                         input_path: str,
                         output_dir: str,
                         num_partitions: int = 200,
                         bucket_name: str = None,
                         compute_norms: bool = True) -> Dict[str, InvertedIndex]:
        """
        Build all three indices (body, title, anchor) in parallel.

        Parameters:
        -----------
        compute_norms : bool, default=True
            Whether to compute pre-normalized L2 norms for cosine similarity

        Returns:
        --------
        dict : {'body': InvertedIndex, 'title': InvertedIndex, 'anchor': InvertedIndex,
                'doc_norms': dict (if compute_norms=True)}
        """
        logger.info("\n" + "="*70)
        logger.info("BUILDING ALL INDICES (BODY, TITLE, ANCHOR)")
        logger.info("="*70 + "\n")

        # Load and cache documents once
        if input_path.endswith('.parquet') or '*.parquet' in input_path:
            docs_df = self.spark.read.parquet(input_path)
        else:
            docs_df = self.spark.read.json(input_path)

        docs_rdd = docs_df.rdd.map(PySparkIndexBuilder.parse_wikipedia_document)
        docs_rdd = docs_rdd.filter(lambda x: x[0] is not None)
        docs_rdd.cache()

        indices = {}

        # Build each index
        for index_type, emit_func in [
            ('body', PySparkIndexBuilder.emit_term_doc_pairs_body),
            ('title', PySparkIndexBuilder.emit_term_doc_pairs_title),
            ('anchor', PySparkIndexBuilder.emit_term_doc_pairs_anchor)
        ]:
            logger.info(f"\n[{index_type.upper()}] Building index...")
            indices[index_type] = self._build_index_generic(
                docs_rdd, emit_func, output_dir, index_type, num_partitions, bucket_name
            )

        # Compute L2 norms for cosine similarity (CRITICAL for SLA)
        if compute_norms:
            logger.info("\n[NORMS] Computing pre-normalized L2 norms for cosine similarity...")
            doc_norms = self._compute_document_norms(
                docs_rdd, indices['body'], output_dir, bucket_name
            )
            indices['doc_norms'] = doc_norms

        docs_rdd.unpersist()

        logger.info("\n" + "="*70)
        logger.info("ALL INDICES BUILT SUCCESSFULLY!")
        logger.info("="*70)

        return indices

    def _compute_document_norms(self,
                                docs_rdd,
                                body_index: InvertedIndex,
                                output_dir: str,
                                bucket_name: str = None) -> Dict[int, float]:
        """
        Compute L2 norms for all documents (for cosine similarity normalization).

        The L2 norm for a document d is:
            norm(d) = sqrt(sum_{t in d} (tf_t * idf_t)^2)

        Pre-computing these norms is CRITICAL for meeting the 35s SLA because:
        - Query-time cosine similarity: score(d,q) = dot(d,q) / (norm(d) * norm(q))
        - Without pre-computed norms, we'd have to compute them for every query
        - This adds ~5-10 seconds per query for large documents

        Parameters:
        -----------
        docs_rdd : RDD
            Documents RDD (doc_id, content_dict)
        body_index : InvertedIndex
            Body index with df values for IDF calculation
        output_dir : str
            Directory to save norms
        bucket_name : str, optional
            GCS bucket

        Returns:
        --------
        dict : doc_id -> L2 norm
        """
        N = len(body_index.df)  # Total number of documents

        def compute_doc_norm(doc_tuple):
            """Compute L2 norm for a single document."""
            doc_id, content = doc_tuple
            if doc_id is None or not content:
                return (doc_id, 0.0)

            body_text = content.get('body', '')
            if not body_text:
                return (doc_id, 0.0)

            # Tokenize
            tokens = tokenize_and_process(body_text, remove_stops=True, stem=True)
            term_counts = Counter(tokens)

            # Compute sum of (tf * idf)^2
            sum_squared = 0.0
            for term, tf in term_counts.items():
                df = body_index.df.get(term, 1)
                idf = math.log(N / df)
                tfidf = tf * idf
                sum_squared += tfidf ** 2

            norm = math.sqrt(sum_squared)
            return (doc_id, norm)

        # Compute norms in parallel
        doc_norms_rdd = docs_rdd.map(compute_doc_norm)
        doc_norms = dict(doc_norms_rdd.collect())

        # Save to disk
        from .inverted_index_gcp import get_bucket, _open
        norms_path = Path(output_dir) / 'doc_norms.pkl'
        bucket = None if bucket_name is None else get_bucket(bucket_name)
        with _open(str(norms_path), 'wb', bucket) as f:
            pickle.dump(doc_norms, f)

        logger.info(f"✓ L2 norms computed for {len(doc_norms):,} documents")
        logger.info(f"  Saved to {norms_path}")

        return doc_norms

    def _build_index_generic(self, docs_rdd, emit_func, output_dir, index_name, num_partitions, bucket_name):
        """Generic index building logic (reused for body/title/anchor)."""
        # MAP
        term_postings_rdd = docs_rdd.flatMap(emit_func)

        # REDUCE
        term_postings_grouped = term_postings_rdd.map(lambda x: (x[0], [x[1]])) \
                                                  .reduceByKey(lambda a, b: a + b, numPartitions=num_partitions)
        term_postings_sorted = term_postings_grouped.mapValues(lambda postings: sorted(postings, key=lambda x: x[0]))

        # Compute stats
        def compute_stats(term_postings_tuple):
            term, postings = term_postings_tuple
            df = len(postings)
            term_total = sum(tf for doc_id, tf in postings)
            return (term, (df, term_total, postings))

        term_stats_rdd = term_postings_sorted.map(compute_stats)
        term_stats = term_stats_rdd.collect()

        # Create index
        index = InvertedIndex()
        for term, (df, term_total, postings) in term_stats:
            index.df[term] = df
            index.term_total[term] = term_total

        # Write posting lists
        self._write_posting_lists_batched(term_stats, output_dir, f'{index_name}_index', bucket_name, index)

        # Write index metadata
        index.write_index(output_dir, f'{index_name}_index', bucket_name)

        logger.info(f"✓ {index_name.upper()} index: {len(index.df):,} terms, {sum(index.df.values()):,} postings")

        return index


def main():
    """
    Entry point for spark-submit.

    Usage:
        spark-submit pyspark_index_builder.py \
            --input gs://wiki-dump/*.parquet \
            --output gs://my-bucket/indices/
    """
    import argparse

    parser = argparse.ArgumentParser(description='Build inverted index using PySpark')
    parser.add_argument('--input', required=True, help='Input path to Wikipedia dump')
    parser.add_argument('--output', required=True, help='Output directory for indices')
    parser.add_argument('--bucket', default=None, help='GCS bucket name')
    parser.add_argument('--partitions', type=int, default=200, help='Number of partitions')

    args = parser.parse_args()

    # Initialize Spark
    conf = SparkConf().setAppName("Wikipedia Index Builder")
    spark = SparkSession.builder.config(conf=conf).getOrCreate()

    # Build indices
    builder = PySparkIndexBuilder(spark)
    indices = builder.build_all_indices(
        input_path=args.input,
        output_dir=args.output,
        num_partitions=args.partitions,
        bucket_name=args.bucket
    )

    logger.info("\n" + "="*70)
    logger.info("INDEX BUILD COMPLETE!")
    logger.info("="*70)

    spark.stop()


if __name__ == "__main__":
    main()
