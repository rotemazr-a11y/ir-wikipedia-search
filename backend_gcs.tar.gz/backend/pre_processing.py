import re
import nltk
from collections import Counter
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

# 1. THE ASSIGNMENT 1 REGEX
RE_WORD = re.compile(r"[\#\w](['\w-]*\w)?", re.UNICODE | re.VERBOSE)

def _get_stop_words():
    """Safely loads NLTK stopwords."""
    try:
        return frozenset(stopwords.words('english'))
    except LookupError:
        import ssl
        try:
            ssl._create_default_https_context = ssl._create_unverified_context
        except AttributeError:
            pass
        nltk.download('stopwords')
        return frozenset(stopwords.words('english'))

ENGLISH_STOP_WORDS = _get_stop_words()

# Initialize Porter Stemmer (lazy loading)
_stemmer = None

def _get_stemmer():
    global _stemmer
    if _stemmer is None:
        _stemmer = PorterStemmer()
    return _stemmer

def tokenize_and_process(text, remove_stops=True, stem=True):
    if not text:
        return []

    # 1. Tokenize (Assignment 1 Regex)
    tokens = [token.group() for token in RE_WORD.finditer(text.lower())]

    # 2. Stopword Removal
    if remove_stops:
        tokens = [t for t in tokens if t not in ENGLISH_STOP_WORDS]

    # 3. Stemming & Cleanup
    stemmer = _get_stemmer()
    processed_tokens = []
    
    for t in tokens:
        # Step 3a: Stem if requested
        if stem:
            t = stemmer.stem(t)
        
        # Step 3b: Strip trailing apostrophes (Fixes "user's" -> "user'" -> "user")
        t = t.rstrip("'")
        
        if t: # Ensure we don't add empty strings
            processed_tokens.append(t)

    return processed_tokens

def get_term_counts(tokens):
    return Counter(tokens)