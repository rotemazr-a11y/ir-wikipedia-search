from flask import Flask, request, jsonify
import math
import pickle
from collections import Counter
from pathlib import Path
import sys

# Add backend to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from inverted_index_gcp import InvertedIndex
from pre_processing import tokenize_and_process

class MyFlaskApp(Flask):
    def run(self, host=None, port=None, debug=None, **options):
        super(MyFlaskApp, self).run(host=host, port=port, debug=debug, **options)

app = MyFlaskApp(__name__)
app.config['JSONIFY_PRETTYPRINT_REGULAR'] = False

# Global variables for indices and metadata (loaded once at startup)
BODY_INDEX = None
TITLE_INDEX = None
ANCHOR_INDEX = None
METADATA = None
PAGERANK = None
PAGEVIEWS = None
INDEX_DIR = None

def load_indices(index_dir="indices"):
    """Load all indices and metadata at startup."""
    global BODY_INDEX, TITLE_INDEX, ANCHOR_INDEX, METADATA, PAGERANK, PAGEVIEWS, INDEX_DIR

    INDEX_DIR = index_dir
    print(f"Loading indices from {index_dir}...")

    try:
        # Load inverted indices
        BODY_INDEX = InvertedIndex.read_index(index_dir, 'body_index')
        print(f"✓ Body index loaded: {len(BODY_INDEX.df)} terms")

        TITLE_INDEX = InvertedIndex.read_index(index_dir, 'title_index')
        print(f"✓ Title index loaded: {len(TITLE_INDEX.df)} terms")

        ANCHOR_INDEX = InvertedIndex.read_index(index_dir, 'anchor_index')
        print(f"✓ Anchor index loaded: {len(ANCHOR_INDEX.df)} terms")

        # Load metadata
        metadata_path = Path(index_dir) / 'metadata.pkl'
        with open(metadata_path, 'rb') as f:
            METADATA = pickle.load(f)
        print(f"✓ Metadata loaded: {METADATA['num_docs']} documents")

        # Load PageRank (optional)
        try:
            pagerank_path = Path(index_dir) / 'pagerank.pkl'
            with open(pagerank_path, 'rb') as f:
                PAGERANK = pickle.load(f)
            print(f"✓ PageRank loaded: {len(PAGERANK)} scores")
        except FileNotFoundError:
            print("⚠ PageRank not found, will return zeros")
            PAGERANK = {}

        # Load page views (optional)
        try:
            pageviews_path = Path(index_dir) / 'pageviews.pkl'
            with open(pageviews_path, 'rb') as f:
                PAGEVIEWS = pickle.load(f)
            print(f"✓ Page views loaded: {len(PAGEVIEWS)} entries")
        except FileNotFoundError:
            print("⚠ Page views not found, will return zeros")
            PAGEVIEWS = {}

        print("✓ All indices loaded successfully!\n")
    except Exception as e:
        print(f"✗ Error loading indices: {e}")
        raise

def compute_tfidf_cosine(query_tokens, index, index_dir, N, use_doc_norms=True):
    """
    Compute TF-IDF cosine similarity scores for all candidate documents.

    Parameters:
    -----------
    query_tokens : list of str
        Preprocessed query tokens
    index : InvertedIndex
        The inverted index to search
    index_dir : str
        Directory containing index files
    N : int
        Total number of documents
    use_doc_norms : bool
        Whether to use precomputed document norms (faster)

    Returns:
    --------
    dict : doc_id -> cosine similarity score
    """
    if not query_tokens:
        return {}

    # 1. Compute query TF-IDF vector and norm
    query_counts = Counter(query_tokens)
    query_tfidf = {}

    for term, count in query_counts.items():
        if term in index.df:
            df = index.df[term]
            idf = math.log(N / df)  # Natural log
            query_tfidf[term] = count * idf

    if not query_tfidf:
        return {}

    # Query L2 norm
    query_norm = math.sqrt(sum(v**2 for v in query_tfidf.values()))

    if query_norm == 0:
        return {}

    # 2. Get candidate documents (documents containing at least one query term)
    candidates = {}

    for term in query_tfidf.keys():
        posting_list = index.read_a_posting_list(index_dir, term)
        for doc_id, tf in posting_list:
            if doc_id not in candidates:
                candidates[doc_id] = {}
            candidates[doc_id][term] = tf

    # 3. Compute cosine similarity for each candidate
    scores = {}

    for doc_id, doc_terms in candidates.items():
        # Dot product
        dot_product = 0.0
        doc_tfidf_squared = 0.0

        for term, tf in doc_terms.items():
            if term in query_tfidf:
                df = index.df[term]
                idf = math.log(N / df)
                doc_tfidf = tf * idf
                dot_product += query_tfidf[term] * doc_tfidf
                doc_tfidf_squared += doc_tfidf ** 2

        # Document norm
        if use_doc_norms and METADATA and 'doc_norms' in METADATA:
            doc_norm = METADATA['doc_norms'].get(doc_id, 0)
        else:
            # Compute on-the-fly (slower)
            doc_norm = math.sqrt(doc_tfidf_squared)

        # Cosine similarity
        if doc_norm > 0:
            scores[doc_id] = dot_product / (query_norm * doc_norm)

    return scores


def binary_ranking(query_tokens, index, index_dir):
    """
    Binary ranking based on distinct query word count in documents.

    Parameters:
    -----------
    query_tokens : list of str
        Preprocessed query tokens
    index : InvertedIndex
        The inverted index to search
    index_dir : str
        Directory containing index files

    Returns:
    --------
    dict : doc_id -> count of distinct query words
    """
    if not query_tokens:
        return {}

    # Use set to count DISTINCT query words (not frequencies)
    query_set = set(query_tokens)

    # Track which query words appear in each document
    doc_matches = {}

    for term in query_set:
        if term in index.df:
            posting_list = index.read_a_posting_list(index_dir, term)
            for doc_id, _ in posting_list:  # Ignore TF for binary ranking
                if doc_id not in doc_matches:
                    doc_matches[doc_id] = set()
                doc_matches[doc_id].add(term)

    # Score = number of distinct query words matched
    scores = {doc_id: len(matched_terms)
              for doc_id, matched_terms in doc_matches.items()}

    return scores


def multi_field_fusion(query_tokens, index_dir, N, metadata,
                       w_body=0.40, w_title=0.25, w_anchor=0.15,
                       w_pagerank=0.15, w_pageviews=0.05):
    """
    Multi-field fusion scoring combining all available signals.

    Scoring Formula:
        score(d) = w_body × cos_sim(q, body_d)
                 + w_title × title_match(q, d)
                 + w_anchor × anchor_match(q, d)
                 + w_pagerank × pagerank(d)
                 + w_pageviews × norm_pageviews(d)

    Parameters:
    -----------
    query_tokens : list
        Preprocessed query tokens (already stemmed)
    index_dir : str
        Index directory path
    N : int
        Total number of documents
    metadata : dict
        Metadata with doc_titles, num_docs, etc.
    w_* : float
        Weights for each signal (should sum to 1.0)

    Returns:
    --------
    dict : doc_id -> final_score
    """
    # 1. Get body TF-IDF scores
    body_scores = compute_tfidf_cosine(query_tokens, BODY_INDEX, index_dir, N)

    # 2. Get title matches (binary ranking)
    title_scores = binary_ranking(query_tokens, TITLE_INDEX, index_dir)

    # 3. Get anchor matches (binary ranking)
    anchor_scores = binary_ranking(query_tokens, ANCHOR_INDEX, index_dir)

    # 4. Normalize binary scores to [0, 1]
    query_terms_count = len(set(query_tokens))
    if query_terms_count > 0:
        title_scores_norm = {doc_id: score / query_terms_count
                            for doc_id, score in title_scores.items()}
        anchor_scores_norm = {doc_id: score / query_terms_count
                             for doc_id, score in anchor_scores.items()}
    else:
        title_scores_norm = {}
        anchor_scores_norm = {}

    # 5. Normalize PageRank to [0, 1]
    if PAGERANK:
        max_pr = max(PAGERANK.values()) if PAGERANK else 1.0
        pagerank_norm = {doc_id: pr / max_pr for doc_id, pr in PAGERANK.items()}
    else:
        pagerank_norm = {}

    # 6. Normalize page views to [0, 1]
    if PAGEVIEWS:
        max_pv = max(PAGEVIEWS.values()) if PAGEVIEWS else 1.0
        pageviews_norm = {doc_id: pv / max_pv for doc_id, pv in PAGEVIEWS.items()}
    else:
        pageviews_norm = {}

    # 7. Get all candidate documents (union of all signals)
    all_docs = set(body_scores.keys()) | set(title_scores.keys()) | set(anchor_scores.keys())

    # 8. Compute weighted fusion score
    final_scores = {}

    for doc_id in all_docs:
        score = 0.0
        score += w_body * body_scores.get(doc_id, 0.0)
        score += w_title * title_scores_norm.get(doc_id, 0.0)
        score += w_anchor * anchor_scores_norm.get(doc_id, 0.0)
        score += w_pagerank * pagerank_norm.get(doc_id, 0.0)
        score += w_pageviews * pageviews_norm.get(doc_id, 0.0)
        final_scores[doc_id] = score

    return final_scores


@app.route("/search")
def search():
    ''' Returns up to a 100 of your best search results for the query. This is
        the place to put forward your best search engine, and you are free to
        implement the retrieval whoever you'd like within the bound of the
        project requirements (efficiency, quality, etc.). That means it is up to
        you to decide on whether to use stemming, remove stopwords, use
        PageRank, query expansion, etc.

        To issue a query navigate to a URL like:
         http://YOUR_SERVER_DOMAIN/search?query=hello+world
        where YOUR_SERVER_DOMAIN is something like XXXX-XX-XX-XX-XX.ngrok.io
        if you're using ngrok on Colab or your external IP on GCP.
    Returns:
    --------
        list of up to 100 search results, ordered from best to worst where each
        element is a tuple (wiki_id, title).
    '''
    res = []
    query = request.args.get('query', '')
    if len(query) == 0:
      return jsonify(res)
    # BEGIN SOLUTION

    # For best search, we can use stemming + combine multiple signals
    query_tokens = tokenize_and_process(query, remove_stops=True, stem=True)

    if not query_tokens:
        return jsonify(res)

    # Use multi-field fusion for best results
    N = METADATA['num_docs']
    final_scores = multi_field_fusion(
        query_tokens,
        INDEX_DIR,
        N,
        METADATA,
        w_body=0.40,      # Body content (TF-IDF)
        w_title=0.25,     # Title matches (high precision)
        w_anchor=0.15,    # Anchor text (external validation)
        w_pagerank=0.15,  # PageRank (popularity)
        w_pageviews=0.05  # Page views (user interest)
    )

    # Sort by score (descending)
    sorted_docs = sorted(final_scores.items(), key=lambda x: x[1], reverse=True)

    # Return top 100 as (doc_id, title) tuples
    for doc_id, score in sorted_docs[:100]:
        title = METADATA['doc_titles'].get(doc_id, "")
        res.append((str(doc_id), title))

    # END SOLUTION
    return jsonify(res)

@app.route("/search_body")
def search_body():
    ''' Returns up to a 100 search results for the query using TFIDF AND COSINE
        SIMILARITY OF THE BODY OF ARTICLES ONLY. DO NOT use stemming. DO USE the
        staff-provided tokenizer from Assignment 3 (GCP part) to do the
        tokenization and remove stopwords.

        To issue a query navigate to a URL like:
         http://YOUR_SERVER_DOMAIN/search_body?query=hello+world
        where YOUR_SERVER_DOMAIN is something like XXXX-XX-XX-XX-XX.ngrok.io
        if you're using ngrok on Colab or your external IP on GCP.
    Returns:
    --------
        list of up to 100 search results, ordered from best to worst where each
        element is a tuple (wiki_id, title).
    '''
    res = []
    query = request.args.get('query', '')
    if len(query) == 0:
      return jsonify(res)
    # BEGIN SOLUTION

    # CRITICAL: Use stem=False per project requirements
    query_tokens = tokenize_and_process(query, remove_stops=True, stem=False)

    if not query_tokens:
        return jsonify(res)

    # Compute TF-IDF cosine similarity
    N = METADATA['num_docs']
    scores = compute_tfidf_cosine(query_tokens, BODY_INDEX, INDEX_DIR, N)

    # Sort by score (descending)
    sorted_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)

    # Return top 100 as (doc_id, title) tuples
    for doc_id, score in sorted_docs[:100]:
        title = METADATA['doc_titles'].get(doc_id, "")
        res.append((str(doc_id), title))

    # END SOLUTION
    return jsonify(res)

@app.route("/search_title")
def search_title():
    ''' Returns ALL (not just top 100) search results that contain A QUERY WORD
        IN THE TITLE of articles, ordered in descending order of the NUMBER OF
        DISTINCT QUERY WORDS that appear in the title. DO NOT use stemming. DO
        USE the staff-provided tokenizer from Assignment 3 (GCP part) to do the
        tokenization and remove stopwords. For example, a document
        with a title that matches two distinct query words will be ranked before a
        document with a title that matches only one distinct query word,
        regardless of the number of times the term appeared in the title (or
        query).

        Test this by navigating to the a URL like:
         http://YOUR_SERVER_DOMAIN/search_title?query=hello+world
        where YOUR_SERVER_DOMAIN is something like XXXX-XX-XX-XX-XX.ngrok.io
        if you're using ngrok on Colab or your external IP on GCP.
    Returns:
    --------
        list of ALL (not just top 100) search results, ordered from best to
        worst where each element is a tuple (wiki_id, title).
    '''
    res = []
    query = request.args.get('query', '')
    if len(query) == 0:
      return jsonify(res)
    # BEGIN SOLUTION

    # CRITICAL: Use stem=False per project requirements
    query_tokens = tokenize_and_process(query, remove_stops=True, stem=False)

    if not query_tokens:
        return jsonify(res)

    # Binary ranking: count distinct query words in title
    scores = binary_ranking(query_tokens, TITLE_INDEX, INDEX_DIR)

    # Sort by score (descending) - returns ALL matches, not top 100
    sorted_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)

    # Return ALL as (doc_id, title) tuples
    for doc_id, score in sorted_docs:
        title = METADATA['doc_titles'].get(doc_id, "")
        res.append((str(doc_id), title))

    # END SOLUTION
    return jsonify(res)

@app.route("/search_anchor")
def search_anchor():
    ''' Returns ALL (not just top 100) search results that contain A QUERY WORD
        IN THE ANCHOR TEXT of articles, ordered in descending order of the
        NUMBER OF QUERY WORDS that appear in anchor text linking to the page.
        DO NOT use stemming. DO USE the staff-provided tokenizer from Assignment
        3 (GCP part) to do the tokenization and remove stopwords. For example,
        a document with a anchor text that matches two distinct query words will
        be ranked before a document with anchor text that matches only one
        distinct query word, regardless of the number of times the term appeared
        in the anchor text (or query).

        Test this by navigating to the a URL like:
         http://YOUR_SERVER_DOMAIN/search_anchor?query=hello+world
        where YOUR_SERVER_DOMAIN is something like XXXX-XX-XX-XX-XX.ngrok.io
        if you're using ngrok on Colab or your external IP on GCP.
    Returns:
    --------
        list of ALL (not just top 100) search results, ordered from best to
        worst where each element is a tuple (wiki_id, title).
    '''
    res = []
    query = request.args.get('query', '')
    if len(query) == 0:
      return jsonify(res)
    # BEGIN SOLUTION

    # CRITICAL: Use stem=False per project requirements
    query_tokens = tokenize_and_process(query, remove_stops=True, stem=False)

    if not query_tokens:
        return jsonify(res)

    # Binary ranking: count distinct query words in anchor text
    scores = binary_ranking(query_tokens, ANCHOR_INDEX, INDEX_DIR)

    # Sort by score (descending) - returns ALL matches, not top 100
    sorted_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)

    # Return ALL as (doc_id, title) tuples
    for doc_id, score in sorted_docs:
        title = METADATA['doc_titles'].get(doc_id, "")
        res.append((str(doc_id), title))

    # END SOLUTION
    return jsonify(res)

@app.route("/get_pagerank", methods=['POST'])
def get_pagerank():
    ''' Returns PageRank values for a list of provided wiki article IDs.

        Test this by issuing a POST request to a URL like:
          http://YOUR_SERVER_DOMAIN/get_pagerank
        with a json payload of the list of article ids. In python do:
          import requests
          requests.post('http://YOUR_SERVER_DOMAIN/get_pagerank', json=[1,5,8])
        As before YOUR_SERVER_DOMAIN is something like XXXX-XX-XX-XX-XX.ngrok.io
        if you're using ngrok on Colab or your external IP on GCP.
    Returns:
    --------
        list of floats:
          list of PageRank scores that corrrespond to the provided article IDs.
    '''
    res = []
    wiki_ids = request.get_json()
    if len(wiki_ids) == 0:
      return jsonify(res)
    # BEGIN SOLUTION

    # Return PageRank scores for each doc_id
    # If doc_id not found, return 0.0
    for doc_id in wiki_ids:
        # Convert to int if it's a string
        if isinstance(doc_id, str):
            doc_id = int(doc_id)

        pr_score = PAGERANK.get(doc_id, 0.0) if PAGERANK else 0.0
        res.append(pr_score)

    # END SOLUTION
    return jsonify(res)

@app.route("/get_pageview", methods=['POST'])
def get_pageview():
    ''' Returns the number of page views that each of the provide wiki articles
        had in August 2021.

        Test this by issuing a POST request to a URL like:
          http://YOUR_SERVER_DOMAIN/get_pageview
        with a json payload of the list of article ids. In python do:
          import requests
          requests.post('http://YOUR_SERVER_DOMAIN/get_pageview', json=[1,5,8])
        As before YOUR_SERVER_DOMAIN is something like XXXX-XX-XX-XX-XX.ngrok.io
        if you're using ngrok on Colab or your external IP on GCP.
    Returns:
    --------
        list of ints:
          list of page view numbers from August 2021 that corrrespond to the
          provided list article IDs.
    '''
    res = []
    wiki_ids = request.get_json()
    if len(wiki_ids) == 0:
      return jsonify(res)
    # BEGIN SOLUTION

    # Return page view counts for each doc_id
    # If doc_id not found, return 0
    for doc_id in wiki_ids:
        # Convert to int if it's a string
        if isinstance(doc_id, str):
            doc_id = int(doc_id)

        pv_count = PAGEVIEWS.get(doc_id, 0) if PAGEVIEWS else 0
        res.append(pv_count)

    # END SOLUTION
    return jsonify(res)

def run(**options):
    app.run(**options)

if __name__ == '__main__':
    # Load indices before starting server
    import os
    index_dir = os.environ.get('INDEX_DIR', 'indices')
    load_indices(index_dir)

    # run the Flask RESTful API, make the server publicly available (host='0.0.0.0') on port 8080
    print(f"\nStarting Flask server on http://0.0.0.0:8080")
    print(f"Endpoints available:")
    print(f"  GET  /search?query=...")
    print(f"  GET  /search_body?query=...")
    print(f"  GET  /search_title?query=...")
    print(f"  GET  /search_anchor?query=...")
    print(f"  POST /get_pagerank  (json: [id1, id2, ...])")
    print(f"  POST /get_pageview  (json: [id1, id2, ...])")
    print()
    app.run(host='0.0.0.0', port=8080, debug=True)
